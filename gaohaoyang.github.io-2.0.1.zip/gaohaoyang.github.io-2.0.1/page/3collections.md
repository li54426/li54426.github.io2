---
layout: page
title: Collections
permalink: /collection/
icon: bookmark
---

* content
{:toc}

## 前端工具

* [box-shadow generator](http://www.cssmatic.com/box-shadow)

    生成 box-shadow 的工具。

* [gradient-generator](http://www.cssmatic.com/gradient-generator)

    渐变生成器。

* [Ultimate CSS Gradient Generator](http://www.colorzilla.com/gradient-editor/)

    也是渐变生成器

* [CSS Generators -CSSREFLEX](http://www.cssreflex.com/css-generators/)

    CSS3 生成器


## ES2015

* [http://www.ecma-international.org/ecma-262/6.0/](http://www.ecma-international.org/ecma-262/6.0/)

    ES2015规范

* [30分钟掌握ES6/ES2015核心内容（上）](http://segmentfault.com/a/1190000004365693)

* [30分钟掌握ES6/ES2015核心内容（下）](http://segmentfault.com/a/1190000004368132)

* [《ECMAScript 6入门》 -阮一峰](https://github.com/ruanyf/es6tutorial)


## 类库与插件

* [Masonry](http://masonry.desandro.com/)

    瀑布流布局库。

* [jssor](http://www.jssor.com/)

    图片轮播图其 GitHub 地址 [jssor/slider](https://github.com/jssor/slider)

* [cssslider](http://cssslider.com/)

    纯 CSS 的图片轮播图。

## 框架

### Vue

* [awesome-vue](https://github.com/vuejs/awesome-vue)
* [Vue.js 和 Webpack（一） -Randy Lu](http://djyde.github.io/2015/08/29/vuejs-and-webpack-1/)
* [Vue.js 和 Webpack（二） -Randy Lu](http://djyde.github.io/2015/08/30/vuejs-and-webpack-2/)
* [Vue.js 和 Webpack（三） -Randy Lu](http://djyde.github.io/2015/08/31/vuejs-and-webpack-3/)
* [Vuejs 1.0 中文系列视频教程 -Laravist](https://laravist.com/series/vue-js-1-0-in-action-series)
* [Vuejs-QQ群 相关资料](https://github.com/jsfront/src/blob/master/vuejs.md) 来自豪情


### React

* [深入理解 React -Thinking in React 中文版](http://reactjs.cn/react/docs/thinking-in-react.html)
* [Thinking in React](http://facebook.github.io/react/docs/thinking-in-react.html)

## 模块化

* [后端程序员的 JavaScript 之旅 - 模块化（一）](http://lishaopeng.com/2016/02/05/js-module/)
* [后端程序员的 JavaScript 之旅 - 模块化（二）](http://lishaopeng.com/2016/02/11/js-module2/)
* [后端程序员的 JavaScript 之旅 - 模块化（三）](http://lishaopeng.com/2016/02/19/js-module3/)

## 技巧

* [将footer固定在页面底部的实现方法](https://segmentfault.com/a/1190000004453249)


## 编辑器

### Atom 中常用插件

* auto-beautify
* autoprefixer
* block-comment
* color-picker
* docblockr
* emmet
* jquery-snippets
* jshint
* linter
* linter-csslint
* linter-htmlhint
* minimap
* minimap-git-diff
* open-in-browser
* uglify
* active-power-mode
* atom-terminal-panel
* linter-scss-linter

常用的主题：

UI Theme: One Dark

Syntax Theme: Atom Dark or One Dark

## GitBook 及其插件

* [Gitbook 的使用和常用插件 -赵达](http://zhaoda.net/2015/11/09/gitbook-plugins/)
* [gitbook-plugin-expandable-chapters](https://plugins.gitbook.com/plugin/expandable-chapters)

    折叠左侧目录章节。

    ![](http://ww4.sinaimg.cn/large/7011d6cfjw1f08kmplbj1j20gn05l0tk.jpg)

## Chrome 插件

* [Chrome扩展及应用开发 -图灵电子书](http://www.ituring.com.cn/minibook/950)

* [有哪些鲜为人知却非常有意思、好用的 Chrome 扩展？ -知乎](https://www.zhihu.com/question/23228162#answer-28057391)
* [Dribbble New Tab](https://chrome.google.com/webstore/detail/dribbble-new-tab/hmhjbefkpednjogghoibpejdmemkinbn)

    新建 tab 时，显示 dribbble 上的精选作品。

## Other blogs

* [凳子_Joinery 邓智容  http://www.dengzhr.com/](http://www.dengzhr.com/)

* [赵达的个人网站 腾讯高级前端开发工程师](http://zhaoda.net/)

* [Randy](http://djyde.github.io/)

    95年出生的全栈。卢涛南，英文名 Randy，用 djyde 这个ID混迹于网络。

* [JS前端开发群月报 -豪情等人维护](http://www.kancloud.cn/jsfront/month/82796)

## Comments

{% include comments.html %}
